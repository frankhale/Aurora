﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Aurora;

namespace $safeprojectname$.Controllers
{
  public class Home : Controller
  {
    [HttpGet("/Index")]
    public ViewResult Index()
    {
      ViewTags["content"] = "Hello, World!";

      return View();
    }
  }
}