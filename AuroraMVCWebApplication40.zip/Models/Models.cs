using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Aurora;

namespace $safeprojectname$.Models
{
  //public class MyModel : Model
  //{ 
  //  // Models are composed of public properties
  //}
}